from flask import Flask, request, jsonify
from flask_cors import CORS
import pytesseract
from PIL import Image, ImageDraw
import os
import string
import base64
from io import BytesIO
import requests
from bs4 import BeautifulSoup
from googletrans import Translator
import nltk

# 初始化 Flask 應用
app = Flask(__name__)
CORS(app)

# Tesseract 路徑
pytesseract.pytesseract.tesseract_cmd = r'C:\\Program Files\\Tesseract-OCR\\tesseract.exe'

# Punkt 和停用詞設置
nltk.download('punkt')
nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

STOPWORDS = set(stopwords.words('english'))
translator = Translator()
@app.route('/drug-side-effects', methods=['GET'])
def get_side_effects():
    drug_name = request.args.get('query')  # 獲取 query 參數
    if not drug_name:
        return jsonify({"error": "Missing 'query' parameter"}), 400

    print(f"Searching for side effects of: {drug_name}")  # 打印出藥品名稱

    url = f'https://www.drugs.com/sfx/{drug_name}-side-effects.html'
    response = requests.get(url)
    if response.status_code != 200:
        return jsonify({"error": f"Failed to retrieve data for {drug_name}. Status code: {response.status_code}"}), 500

    soup = BeautifulSoup(response.text, 'html.parser')
    h2 = soup.find('h2', {'class': 'ddc-anchor-offset'})

    if not h2:
        return jsonify({"error": "No side effects information found."}), 404

    # 提取副作用數據
    data = {"drug_name": drug_name, "title": h2.get_text(strip=True), "description": []}
    paragraphs = h2.find_all_next('p', limit=2)
    for paragraph in paragraphs:
        # 翻譯每個段落並加入描述，但保留藥名
        text = paragraph.get_text(strip=True)
        translated_text = translator.translate(text.replace(drug_name, f"[[{drug_name}]]"), src='en', dest='zh-tw').text
        # 恢復藥名原始格式
        translated_text = translated_text.replace(f"[[{drug_name}]]", drug_name)
        data["description"].append(translated_text)

    details = h2.find_next('details')
    if details:
        h3 = details.find('h3')
        if h3:
            # 翻譯副標題，但保留藥名
            text = h3.get_text(strip=True)
            translated_text = translator.translate(text.replace(drug_name, f"[[{drug_name}]]"), src='en', dest='zh-tw').text
            data["sub_title"] = translated_text.replace(f"[[{drug_name}]]", drug_name)
        ul = details.find('ul')
        if ul:
            # 翻譯副作用清單，但保留藥名
            data["side_effects"] = [
                translator.translate(li.get_text(strip=True).replace(drug_name, f"[[{drug_name}]]"), src='en', dest='zh-tw').text.replace(f"[[{drug_name}]]", drug_name)
                for li in ul.find_all('li')
            ]

    return jsonify(data)
# 上傳圖片接口
@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part in the request'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected for uploading'}), 400

    try:
        # 讀取圖片
        img = Image.open(file)
        
        # OCR 辨識文字
        custom_config = r'--oem 3 --psm 6'
        text = pytesseract.image_to_string(img, config=custom_config)
        boxes = pytesseract.image_to_boxes(img, config=custom_config)

        # 繪製紅框
        draw = ImageDraw.Draw(img)
        img_height = img.height
        for b in boxes.splitlines():
            b = b.split(' ')
            x, y, x2, y2 = int(b[1]), int(b[2]), int(b[3]), int(b[4])
            draw.rectangle([x, img_height - y2, x2, img_height - y], outline="red", width=3)

        # 保存結果為 base64
        buffered = BytesIO()
        img.save(buffered, format="PNG")
        img_str = base64.b64encode(buffered.getvalue()).decode()

        # 分詞處理
        tokens = word_tokenize(text)
        filtered_words = [word for word in tokens if word.lower() not in STOPWORDS and word not in string.punctuation]

        # 爬取數據
        drug_data = []
        for drug_name in filtered_words:
            drug_info = scrape_drug_info(drug_name)
            if drug_info:
                drug_data.append(drug_info)

        return jsonify({'text': text, 'image': img_str, 'drug_data': drug_data})

    except Exception as e:
        return jsonify({'error': str(e)}), 500

# 爬蟲邏輯
translator = Translator()

def scrape_drug_info(drug_name):
    url = f'https://www.drugs.com/sfx/{drug_name}-side-effects.html'
    response = requests.get(url)

    # 檢查請求是否成功
    if response.status_code != 200:
        return {
            'title': '無法獲得資料',
            'drug_name': drug_name,
            'description': ['未找到該藥物的描述資料。'],
            'side_effects': ['無副作用資料。'],
        }

    soup = BeautifulSoup(response.text, 'html.parser')

    # 檢查頁面是否包含有效的標題
    h2 = soup.find('h2', {'class': 'ddc-anchor-offset'})
    if not h2:
        return {
            'title': '無法獲得資料',
            'drug_name': drug_name,
            'description': ['未找到該藥物的描述資料。'],
            'side_effects': ['無副作用資料。'],
        }

    # 提取描述段落
    paragraphs = [p.get_text(strip=True) for p in h2.find_all_next('p', limit=2)]
    
    # 查找並提取副作用列表
    details = h2.find_next('details')
    side_effects = []
    if details:
        ul = details.find('ul')
        if ul:
            side_effects = [li.get_text(strip=True) for li in ul.find_all('li')]

    # 翻譯藥物名稱和描述
    try:
        translated_title = translator.translate(h2.get_text(strip=True), src='en', dest='zh-tw').text
        translated_description = [translator.translate(p, src='en', dest='zh-tw').text for p in paragraphs]
    except Exception as e:
        translated_title = h2.get_text(strip=True)
        translated_description = paragraphs

    # 返回爬取並翻譯後的資料
    return {
        'title': translated_title,
        'drug_name': drug_name,
        'description': translated_description if translated_description else ['未找到描述資料。'],
        'side_effects': side_effects if side_effects else ['無副作用資料。'],
    }

# 主程序
if __name__ == '__main__':
    app.run(debug=True, port=5000)
