<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384- GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
<link rel="icon" href="header/logoo.png" sizes="32x32" type="image/png">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<style>
    header {
        padding: 25px 10px;
        display: flex;
        justify-content: space-between;
        background-color: #f3f3f3;
    }
    .logo {
        align-self: center;
    }
    .block0 {
        display: flex;
        justify-content: center;
    }
    .imgheader {
        width: 2.5vw;
        height: auto;
        align-self: center;
    }
    button {
        padding: 7px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    button:focus, button:active {
        outline: none;
    }
    .navitem {
        display: flex;
        justify-content: center;
    }
    #uploadResult, #searchResult {
            display: none; /* 初始隱藏 */
    }
</style>
</head>
<body>
<header>
    <div class="logo">
        <a href="hindex.php"><img src="header/logo.png" alt="PharmaInsight" width="35%" height="35%"></a>
    </div>
    <form id="searchForm">
    <div class="block0">
        <div class="navitem">
            <input type="text" id="inputBox" style="display:none;" placeholder="search?">
        </div>
        <div class="navitem">
            <button type="button" onclick="searchfunc(event)"><img src="header/search.png" alt="search" width="30%" height="30%" class="imgheader"></button>
        </div>
    </div>
    </form>
</header>

<div class="container mt-5">
    <h2>Upload an Image to Analyze Drug Information</h2>
    <form id="uploadForm" enctype="multipart/form-data">
        <input type="file" id="imageFile" name="file" accept="image/*" required>
        <button type="button" class="btn btn-primary" onclick="uploadImage()">Upload</button>
    </form>
    <div id="uploadResult"></div>
</div>

<div class="container mt-5" id="searchResult"></div>

<script>
var x = 0;

function searchfunc(event) {
    event.preventDefault(); // 阻止表單提交，避免重新載入頁面

    var inputBox = document.getElementById("inputBox");

    if (x === 0) {
        x = 1;
        inputBox.style.display = "block"; // 顯示輸入框
    } else {
        x = 0;
        var query = inputBox.value.trim();
        if (query) {
            inputBox.style.display = "none";

            // 隱藏上傳結果區域
            document.getElementById("uploadResult").style.display = "none";

            fetch("http://localhost:5000/drug-side-effects?query=" + query)
                .then(response => {
                    if (!response.ok) {
                        throw new Error("沒有找到該藥物的資訊耶哭哭");
                    }
                    return response.json();
                })
                .then(data => {
                    console.log("Received response:", data);

                    var searchResult = document.getElementById("searchResult");
                    // 顯示搜尋結果區域
                    searchResult.style.display = "block";

                    if (data.error) {
                        searchResult.innerHTML = `<h3>Error</h3><p>${data.error}</p>`;
                    } else {
                        searchResult.innerHTML = `
                            <h3>${data.title}</h3>
                            <p><strong>Drug Name:</strong> ${data.drug_name}</p>
                            <p><strong>Description:</strong> ${data.description.join('<br>')}</p>
                            ${data.side_effects.length > 0 ? 
                                `<h4>Possible Side Effects:</h4>
                                 <ul>
                                    ${data.side_effects.map(effect => `<li>${effect}</li>`).join('')}
                                 </ul>` 
                                : '<p>No side effects information available.</p>'}
                        `;
                    }
                })
                .catch(error => {
                    console.error("Error:", error);

                    var searchResult = document.getElementById("searchResult");
                    searchResult.style.display = "block";
                    searchResult.innerHTML = `<h3>No results found for: ${query}</h3><p>${error.message}</p>`;
                });
        } else {
            inputBox.style.display = "none";
        }
    }
}

function uploadImage() {
    const formData = new FormData(document.getElementById('uploadForm'));

    // 隱藏搜尋結果區域
    document.getElementById("searchResult").style.display = "none";

    fetch("http://localhost:5000/upload", {
        method: "POST",
        body: formData,
    })
    .then(response => response.json())
    .then(data => {
        const uploadResult = document.getElementById("uploadResult");
        // 顯示上傳結果區域
        uploadResult.style.display = "block";

        if (data.error) {
            uploadResult.innerHTML = `<p class="text-danger">Error: ${data.error}</p>`;
        } else {
            uploadResult.innerHTML = `
                <h3>Analyzed Result</h3>
                <p><strong>辨識出的文字:</strong> ${data.text}</p>
                <img src="data:image/png;base64,${data.image}" alt="Analyzed Image">
            `;
            displayDrugData(data.drug_data);
        }
    })
    .catch(err => console.error("Upload error:", err));
}

function displayDrugData(drugData) {
    const uploadResult = document.getElementById("uploadResult");
    if (drugData.length === 0) {
        uploadResult.innerHTML += "<p>無法獲得藥物資料。</p>";
        return;
    }
    uploadResult.innerHTML += drugData.map(data => `
        <div>
            <h3>${data.title}</h3>
            <p><strong>藥物名稱:</strong> ${data.drug_name}</p>
            <p><strong>描述:</strong> ${data.description.join('<br>')}</p>
            ${data.side_effects.length > 0 ? `
                <h4>可能的副作用:</h4>
                <ul>${data.side_effects.map(effect => `<li>${effect}</li>`).join('')}</ul>
            ` : '<p>無副作用資料。</p>'}
        </div>
    `).join('');
}
</script>

</body>
</html>
